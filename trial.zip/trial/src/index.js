//Import stylesheets
import "./style.css"
//Imoprt LIFF SDK
import liff from "@line/liff";

//Body element
const body = document.getElementById("body")

const pictureUrl = document.getElementById("pictureUrl")
const userId = document.getElementById("userId")
const displayName = document.getElementById("displayName")
const statusMessage = document.getElementById("statusMessage")
const email = document.getElementById("email")

const btnShare  = document.getElementById("btnShare")

async function main(){
    liff.ready.then(() => {
        if(liff.getOS() === "android"){
            body.style.background = "#226188"
        }
        if(liff.isInClient()){
            getUserProfile()
        }
    })


    await liff.init({liffId: "2003556825-NAK5W0Az"})
}

main();


async function getUserProfile(){
    const profile = await liff.getProfile()

    pictureUrl.src = profile.pictureUrl
    userId.innerHTML = "<b>userId: </b>" +profile.userId
    displayName.innerHTML = "<b>displayName: </b>" +profile.displayName
}

async function shareMsg(){
    const result = await liff.shareTargetPicker([
        {
            type: "text",
            text: "This message is sent through LIFF app"
        }
    ])
    if(result){
        alert("Message was shared!!")
    }else{
        alert("some error occured and message not sent")
    }
    //If i want the LIFF to close after sending the message i'd uncomment the following code:
    //liff.closeWindow()
}

btnShare.onclick = () =>{
    shareMsg()
}